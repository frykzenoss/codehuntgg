import { useState, useEffect, useCallback } from "react";
import Prism from "prismjs";
import "prismjs/themes/prism-tomorrow.css";
import "prismjs/components/prism-javascript";
import "prismjs/components/prism-typescript";
import "prismjs/components/prism-python";
import "prismjs/components/prism-go";
import "prismjs/components/prism-rust";
import "prismjs/components/prism-java";
import "prismjs/components/prism-css";
import "prismjs/components/prism-markup";
import "prismjs/components/prism-cpp";
import "prismjs/components/prism-ruby";

// In dev, Vite proxies /api → Netlify CLI. In prod, same domain.
const API = "/api";

const CLIENT_ID = import.meta.env.VITE_GITHUB_CLIENT_ID;

const LANGS = [
  { name: "JavaScript", filter: "javascript", color: "#f1e05a" },
  { name: "TypeScript", filter: "typescript", color: "#3178c6" },
  { name: "Python",     filter: "python",     color: "#3572A5" },
  { name: "HTML",       filter: "html",       color: "#e34c26" },
  { name: "CSS",        filter: "css",        color: "#563d7c" },
  { name: "Go",         filter: "go",         color: "#00ADD8" },
  { name: "Rust",       filter: "rust",       color: "#dea584" },
  { name: "Java",       filter: "java",       color: "#b07219" },
  { name: "C++",        filter: "c++",        color: "#f34b7d" },
  { name: "Ruby",       filter: "ruby",       color: "#701516" },
];

function CodeBlock({ code, lang }) {
  const key = lang?.toLowerCase();
  const grammar = Prism.languages[key] || Prism.languages.javascript;
  const html = Prism.highlight(code, grammar, key || "javascript");
  return (
    <pre className="code-pre">
      <code dangerouslySetInnerHTML={{ __html: html }} />
    </pre>
  );
}

function Card({ result, index }) {
  const [copied, setCopied] = useState(false);
  const color = LANGS.find(l => l.name === result.lang)?.color || "#8b949e";

  const copy = () => {
    navigator.clipboard.writeText(result.snippet).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="card" style={{ animationDelay: `${index * 0.07}s` }}>
      <div className="card-top">
        <div className="card-left">
          <a className="card-repo" href={result.repoUrl} target="_blank" rel="noreferrer">
            {result.repo}
          </a>
          <div className="card-meta">
            <span className="card-stars">⭐ {result.stars.toLocaleString()}</span>
            <span className="card-lang-badge">
              <span className="dot" style={{ background: color }} />
              {result.lang}
            </span>
          </div>
        </div>
        <span className="card-path" title={result.path}>{result.path}</span>
      </div>
      <div className="code-wrap">
        <CodeBlock code={result.snippet} lang={result.lang} />
      </div>
      <div className="card-bottom">
        <button className={`copy-btn${copied ? " ok" : ""}`} onClick={copy}>
          {copied ? "✓ Copied" : "Copy snippet"}
        </button>
        <a className="view-link" href={result.fileUrl} target="_blank" rel="noreferrer">
          View on GitHub ↗
        </a>
      </div>
    </div>
  );
}

function Skeleton() {
  return (
    <div className="skeleton">
      <div className="skel-top">
        <div className="skel-line" style={{ width: "160px", height: "14px" }} />
        <div className="skel-line" style={{ width: "55px",  height: "14px" }} />
      </div>
      <div className="skel-body">
        {[90,70,85,55,78,65,92,60].map((w, i) => (
          <div key={i} className="skel-line" style={{ width: `${w}%`, height: "12px" }} />
        ))}
      </div>
    </div>
  );
}

// ── Token stored only in sessionStorage (cleared when tab closes) ──────────
function getStoredToken() { return sessionStorage.getItem("gh_token") || null; }
function storeToken(t)    { sessionStorage.setItem("gh_token", t); }
function clearToken()     { sessionStorage.removeItem("gh_token"); }

export default function App() {
  const [token,    setToken]    = useState(getStoredToken);
  const [user,     setUser]     = useState(null);
  const [query,    setQuery]    = useState("");
  const [lang,     setLang]     = useState(LANGS[0]);
  const [results,  setResults]  = useState([]);
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState("");
  const [searched, setSearched] = useState(false);

  // After GitHub redirects back with ?code=...
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code   = params.get("code");
    if (!code) return;

    // Clean URL immediately so code isn't reused
    window.history.replaceState({}, "", "/");

    // Exchange code → token via our serverless function (client secret stays safe)
    fetch(`${API}/auth?code=${code}`)
      .then(r => r.json())
      .then(data => {
        if (data.token) {
          storeToken(data.token);
          setToken(data.token);
        } else {
          setError(data.error || "OAuth failed");
        }
      })
      .catch(() => setError("OAuth exchange failed"));
  }, []);

  // Fetch user info whenever token changes
  useEffect(() => {
    if (!token) { setUser(null); return; }
    fetch("https://api.github.com/user", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(r => r.ok ? r.json() : null)
      .then(u => { if (u) setUser(u); })
      .catch(() => {});
  }, [token]);

  const login = () => {
    const url = `https://github.com/login/oauth/authorize?client_id=${CLIENT_ID}&scope=public_repo`;
    window.location.href = url;
  };

  const logout = () => {
    clearToken();
    setToken(null);
    setUser(null);
    setResults([]);
    setSearched(false);
    setError("");
  };

  const search = useCallback(async () => {
    if (!query.trim() || !token) return;
    setLoading(true);
    setError("");
    setResults([]);
    setSearched(true);

    try {
      const r = await fetch(`${API}/search`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ q: query, lang: lang.filter, token }),
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Search failed");
      setResults(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [query, lang, token]);

  return (
    <div className="app">
      <header>
        <div className="logo">
          <div className="logo-mark">
            <svg viewBox="0 0 16 16" fill="#0d1117" width="18" height="18">
              <path d="M2 2h12v2H2V2zm0 4h8v2H2V6zm0 4h10v2H2v-2z"/>
            </svg>
          </div>
          <span className="logo-name">CodeHunt</span>
          <span className="logo-tag">BETA</span>
        </div>

        {user ? (
          <div className="user-row">
            <img className="avatar" src={user.avatar_url} alt={user.login} />
            <span className="username">{user.login}</span>
            <button className="logout-btn" onClick={logout}>Sign out</button>
          </div>
        ) : (
          <button className="login-btn" onClick={login}>
            <GhIcon /> Sign in with GitHub
          </button>
        )}
      </header>

      {!token ? (
        <div className="splash">
          <h1>Hunt for real code<br /><span>across GitHub</span></h1>
          <p>Sign in with GitHub to search millions of real repositories — no token pasting, no config.</p>
          <button className="login-btn big" onClick={login}>
            <GhIcon size={20} /> Sign in with GitHub
          </button>
        </div>
      ) : (
        <>
          <div className="search-section">
            <div className="search-label">Language</div>
            <div className="lang-row">
              {LANGS.map(l => (
                <button
                  key={l.name}
                  className={`lang-btn${lang.name === l.name ? " selected" : ""}`}
                  onClick={() => setLang(l)}
                >
                  <span className="dot" style={{ background: lang.name === l.name ? l.color : l.color + "88" }} />
                  {l.name}
                </button>
              ))}
            </div>

            <div className="search-label" style={{ marginTop: 16 }}>Search</div>
            <div className="input-row">
              <input
                className="search-input"
                placeholder="random number generator"
                value={query}
                onChange={e => setQuery(e.target.value)}
                onKeyDown={e => e.key === "Enter" && search()}
              />
              <button className="search-btn" onClick={search} disabled={loading || !query.trim()}>
                {loading ? "Hunting…" : "Search"}
              </button>
            </div>
          </div>

          {error && <div className="error-msg">❌ {error}</div>}

          {loading && <div className="results">{[0,1,2].map(i => <Skeleton key={i} />)}</div>}

          {!loading && searched && !error && results.length === 0 && (
            <div className="empty">
              <h3>No results found</h3>
              <p>Try different keywords or switch language</p>
            </div>
          )}

          {!loading && results.length > 0 && (
            <>
              <div className="results-header">
                <span className="results-count">{results.length} result{results.length !== 1 ? "s" : ""}</span>
                <span className="active-badge">
                  <span className="dot" style={{ background: lang.color }} />
                  {lang.name}
                </span>
              </div>
              <div className="results">
                {results.map((r, i) => <Card key={i} result={r} index={i} />)}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}

function GhIcon({ size = 16 }) {
  return (
    <svg viewBox="0 0 16 16" fill="currentColor" width={size} height={size}>
      <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"/>
    </svg>
  );
}
