// netlify/functions/auth.js
// Handles GET /api/auth?code=... — exchanges GitHub OAuth code for access token
// The client secret lives only here, never in the browser.

export async function handler(event) {
  const code = event.queryStringParameters?.code;

  if (!code) {
    return { statusCode: 400, body: JSON.stringify({ error: "Missing code" }) };
  }

  try {
    const res = await fetch("https://github.com/login/oauth/access_token", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: JSON.stringify({
        client_id:     process.env.GITHUB_CLIENT_ID,
        client_secret: process.env.GITHUB_CLIENT_SECRET,
        code,
      }),
    });

    const data = await res.json();

    if (!data.access_token) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: data.error_description || "OAuth failed" }),
      };
    }

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: data.access_token }),
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
}
