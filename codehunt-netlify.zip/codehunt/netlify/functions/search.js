// netlify/functions/search.js
// Handles POST /api/search — proxies GitHub Code Search API server-side

const SKIP = /readme|changelog|license|contributing|\.md$|\.txt$|\.rst$|\.json$|\.yaml$|\.yml$|\.toml$|\.lock$|\.xml$|news$|authors$|todo$/i;

const CODE_SIGNALS = /function |def |class |const |let |var |fn |pub |import |return |if\s*\(|for\s*\(|async |await |=>|:=|\bmodule\b|\bexport\b/;

const LANG_EXT = {
  javascript: [".js", ".jsx", ".mjs"],
  typescript: [".ts", ".tsx"],
  python:     [".py"],
  html:       [".html", ".htm"],
  css:        [".css", ".scss"],
  go:         [".go"],
  rust:       [".rs"],
  java:       [".java"],
  "c++":      [".cpp", ".cc", ".hpp"],
  ruby:       [".rb"],
};

function buildRawUrl(htmlUrl) {
  const m = htmlUrl.match(/^https:\/\/github\.com\/([^/]+)\/([^/]+)\/blob\/([^/]+)\/(.+)$/);
  if (!m) return null;
  return `https://raw.githubusercontent.com/${m[1]}/${m[2]}/${m[3]}/${m[4]}`;
}

function extractSnippet(content, keywords, ctx = 22) {
  const lines = content.split("\n");
  const kws   = keywords.toLowerCase().split(/\s+/).filter(k => k.length > 2);
  let best = 0, bestScore = -Infinity;

  lines.forEach((line, i) => {
    const ll = line.toLowerCase();
    let score = kws.reduce((s, k) => s + (ll.includes(k) ? 3 : 0), 0);
    if (CODE_SIGNALS.test(line)) score += 5;
    if (/^\s*(\/\/|#|\/\*|\*|<!--)/.test(line) && !kws.some(k => ll.includes(k))) score -= 2;
    if (score > bestScore) { bestScore = score; best = i; }
  });

  const start = Math.max(0, best - ctx);
  const end   = Math.min(lines.length - 1, best + ctx);
  return lines.slice(start, end + 1).join("\n");
}

export async function handler(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }

  let body;
  try { body = JSON.parse(event.body); }
  catch { return { statusCode: 400, body: "Invalid JSON" }; }

  const { q, lang, token } = body;
  if (!q || !token) return { statusCode: 400, body: "Missing q or token" };

  const cleaned = q
    .replace(/\b(how|to|make|a|an|the|in|for|with|using|create|build|write|simple|basic|example)\b/gi, "")
    .replace(/\s+/g, " ").trim();

  const ghQ = `${encodeURIComponent(cleaned)}+language:${lang || "javascript"}`;

  const authH = {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github.v3.text-match+json",
  };
  const plainH = {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github.v3+json",
  };

  try {
    const searchRes = await fetch(
      `https://api.github.com/search/code?q=${ghQ}&per_page=40&sort=indexed`,
      { headers: authH }
    );

    if (!searchRes.ok) {
      const e = await searchRes.json();
      return { statusCode: searchRes.status, body: JSON.stringify({ error: e.message }) };
    }

    const searchData = await searchRes.json();
    const exts = LANG_EXT[lang?.toLowerCase()] || [];

    let items = (searchData.items || []).filter(i => !SKIP.test(i.path));
    const byExt = items.filter(i => exts.some(e => i.path.toLowerCase().endsWith(e)));
    items = (byExt.length ? byExt : items).slice(0, 10);

    const results = await Promise.all(items.map(async item => {
      const repoFull = item.repository.full_name;
      let stars = 0, snippet = "";

      const [starsRes, rawRes] = await Promise.all([
        fetch(`https://api.github.com/repos/${repoFull}`, { headers: plainH }),
        (rawUrl => rawUrl ? fetch(rawUrl, { headers: { Authorization: `Bearer ${token}` } }) : null)(buildRawUrl(item.html_url)),
      ]);

      if (starsRes.ok) { try { stars = (await starsRes.json()).stargazers_count || 0; } catch {} }
      if (rawRes?.ok)  { try { snippet = extractSnippet(await rawRes.text(), cleaned); } catch {} }

      if (!snippet && item.text_matches?.length) {
        snippet = item.text_matches.map(m => m.fragment || "").filter(Boolean).join("\n\n");
      }
      if (!snippet) snippet = '// Click "View on GitHub" to see this file';

      return {
        repo:    repoFull,
        stars,
        lang:    item.repository.language || lang,
        path:    item.path,
        repoUrl: item.repository.html_url,
        fileUrl: item.html_url,
        snippet,
      };
    }));

    results.sort((a, b) => b.stars - a.stars);

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(results),
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
}
